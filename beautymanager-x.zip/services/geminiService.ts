import { GoogleGenAI } from "@google/genai";

const apiKey = process.env.API_KEY || '';
const ai = new GoogleGenAI({ apiKey });

export const sendMessageToGemini = async (message: string): Promise<string> => {
  try {
    const response = await ai.models.generateContent({
      model: 'gemini-3-pro-preview',
      contents: message,
      config: {
        systemInstruction: "You are a helpful and professional assistant for a beauty salon management app called 'BeautyManager Pro'. You help the stylist manage appointments, client queries, and business tips. Keep answers concise and friendly.",
      }
    });
    
    return response.text || "Lo siento, no pude generar una respuesta en este momento.";
  } catch (error) {
    console.error("Error communicating with Gemini:", error);
    return "Ocurrió un error al conectar con el asistente. Por favor verifica tu conexión o intenta más tarde.";
  }
};