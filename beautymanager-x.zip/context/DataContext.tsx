import React, { createContext, useContext, useState, ReactNode } from 'react';
import { Appointment, Client, UserProfile, Professional } from '../types';

interface DataContextType {
    appointments: Appointment[];
    clients: Client[];
    userProfile: UserProfile;
    professionals: Professional[];
    addAppointment: (appt: Appointment) => void;
    addClient: (client: Client) => void;
    updateAppointmentStatus: (id: number, status: 'confirmed' | 'pending' | 'cancelled') => void;
    deleteAppointment: (id: number) => void;
    updateUserProfile: (profile: Partial<UserProfile>) => void;
    addProfessional: (pro: Professional) => void; // Nuevo
    updateProfessional: (id: number, data: Partial<Professional>) => void;
    deleteProfessional: (id: number) => void; // Nuevo
}

const DataContext = createContext<DataContextType | undefined>(undefined);

export const DataProvider: React.FC<{ children: ReactNode }> = ({ children }) => {
    // Datos iniciales de ejemplo para Citas
    const [appointments, setAppointments] = useState<Appointment[]>([
        { id: 1, time: '10:00', ampm: 'AM', client: 'Ana García', service: 'Semipermanente Manos', duration: '2h 0m', avatar: 'https://picsum.photos/id/65/200/200', status: 'confirmed', professionalId: 1, professionalName: 'Maria Gonzalez', price: '$55.000' },
        { id: 2, time: '12:30', ampm: 'PM', client: 'Carlos Ruiz', service: 'Masaje Relajante', duration: '1h 0m', avatar: 'https://picsum.photos/id/91/200/200', status: 'pending', professionalId: 2, professionalName: 'Sofia Martinez', price: '$90.000' }
    ]);

    // Datos iniciales de ejemplo para Clientes
    const [clients, setClients] = useState<Client[]>([
        { id: 101, name: 'Ana García', lastVisit: '12 Oct', phone: '5512345678', email: 'ana.garcia@email.com', avatar: 'https://picsum.photos/id/65/200/200' },
        { id: 102, name: 'Carlos Ruiz', lastVisit: 'Nuevo', phone: '5587654321', email: 'carlos.ruiz@email.com', avatar: 'https://picsum.photos/id/91/200/200', isNew: true }
    ]);

    // Lista de Profesionales del Salón
    const [professionals, setProfessionals] = useState<Professional[]>([
        { 
            id: 1, 
            name: 'Maria Gonzalez', 
            role: 'Manicurista Senior', 
            avatar: 'https://picsum.photos/id/64/300/300', 
            specialties: ['Semipermanente Manos', 'Soft Gel', 'Nivelación Base Ruber', 'Corte de Cabello'] 
        },
        { 
            id: 2, 
            name: 'Sofia Martinez', 
            role: 'Esteticista', 
            avatar: 'https://picsum.photos/id/40/300/300', 
            specialties: ['Masaje Relajante', 'Depilación de Axilas', 'Epilación de Cejas'] 
        },
        { 
            id: 3, 
            name: 'David Torres', 
            role: 'Técnico en Uñas', 
            avatar: 'https://picsum.photos/id/55/300/300', 
            specialties: ['Builder Gel', 'Dipping', 'Semipermanente Hombre'] 
        }
    ]);

    // Perfil de Usuario y Configuración
    const [userProfile, setUserProfile] = useState<UserProfile>({
        name: 'Maria Gonzalez',
        role: 'Manicurista Senior',
        specialty: 'Soft Gel y Nail Art',
        phone: '+34 612 345 678',
        email: 'maria.g@beautymanager.com',
        avatar: 'https://picsum.photos/id/64/300/300',
        isGoogleCalendarConnected: true,
        schedule: [
            { day: 'Lunes', enabled: true, start: '09:00', end: '18:00' },
            { day: 'Martes', enabled: true, start: '09:00', end: '18:00' },
            { day: 'Miércoles', enabled: true, start: '09:00', end: '18:00' },
            { day: 'Jueves', enabled: true, start: '09:00', end: '18:00' },
            { day: 'Viernes', enabled: true, start: '09:00', end: '18:00' },
            { day: 'Sábado', enabled: true, start: '10:00', end: '14:00' },
            { day: 'Domingo', enabled: false, start: '09:00', end: '18:00' },
        ]
    });

    const addAppointment = (appt: Appointment) => {
        setAppointments(prev => [...prev, appt].sort((a, b) => a.time.localeCompare(b.time)));
    };

    const addClient = (client: Client) => {
        setClients(prev => [client, ...prev]);
    };

    const updateAppointmentStatus = (id: number, status: 'confirmed' | 'pending' | 'cancelled') => {
        setAppointments(prev => prev.map(appt => appt.id === id ? { ...appt, status } : appt));
    };

    const deleteAppointment = (id: number) => {
        setAppointments(prev => prev.filter(appt => appt.id !== id));
    };

    const updateUserProfile = (data: Partial<UserProfile>) => {
        setUserProfile(prev => ({ ...prev, ...data }));
    };

    const addProfessional = (pro: Professional) => {
        setProfessionals(prev => [...prev, pro]);
    };

    const updateProfessional = (id: number, data: Partial<Professional>) => {
        setProfessionals(prev => prev.map(p => p.id === id ? { ...p, ...data } : p));
    };

    const deleteProfessional = (id: number) => {
        setProfessionals(prev => prev.filter(p => p.id !== id));
    };

    return (
        <DataContext.Provider value={{ 
            appointments, 
            clients, 
            userProfile, 
            professionals,
            addAppointment, 
            addClient, 
            updateAppointmentStatus, 
            deleteAppointment,
            updateUserProfile,
            addProfessional,
            updateProfessional,
            deleteProfessional
        }}>
            {children}
        </DataContext.Provider>
    );
};

export const useData = () => {
    const context = useContext(DataContext);
    if (!context) {
        throw new Error('useData must be used within a DataProvider');
    }
    return context;
};