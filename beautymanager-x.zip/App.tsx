import React from 'react';
import { HashRouter, Routes, Route } from 'react-router-dom';
import Layout from './components/Layout';
import Dashboard from './pages/Dashboard';
import Agenda from './pages/Agenda';
import Clients from './pages/Clients';
import Team from './pages/Team'; // Importar nueva página
import Settings from './pages/Settings';
import { DataProvider } from './context/DataContext';

const App: React.FC = () => {
    return (
        <DataProvider>
            <HashRouter>
                <Layout>
                    <Routes>
                        <Route path="/" element={<Dashboard />} />
                        <Route path="/agenda" element={<Agenda />} />
                        <Route path="/clients" element={<Clients />} />
                        <Route path="/team" element={<Team />} /> {/* Nueva ruta */}
                        <Route path="/settings" element={<Settings />} />
                    </Routes>
                </Layout>
            </HashRouter>
        </DataProvider>
    );
};

export default App;